#include <stdio.h>
#include <openssl/sha.h>

#define BUFSIZE 4096

int sha256_file(char* path, unsigned char* hash) {
    FILE* file = fopen(path, "rb");
    if (!file) {
        return 0;
    }

    SHA256_CTX ctx;
    SHA256_Init(&ctx);

    unsigned char buf[BUFSIZE];
    size_t bytes_read;

    while ((bytes_read = fread(buf, 1, BUFSIZE, file))) {
        SHA256_Update(&ctx, buf, bytes_read);
    }

    SHA256_Final(hash, &ctx);

    fclose(file);
    return 1;
}

int main(int argc, char *argv[]) {
    char* path = argv[1];
    unsigned char hash[SHA256_DIGEST_LENGTH];

    if (sha256_file(path, hash)) {
        printf("SHA256 hash of %s: ", path);
        for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
            printf("%02x", hash[i]);
        }
        printf("\n");
    } else {
        printf("Error: could not calculate SHA256 hash of %s\n", path);
    }
    return 0;
}
